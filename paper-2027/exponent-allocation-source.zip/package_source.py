#!/usr/bin/env python3
"""Package the active manuscript and its exact TeX dependencies."""
from __future__ import annotations

import hashlib
import ast
import re
import zipfile
import json
import subprocess
from pathlib import Path

PAPER = Path(__file__).resolve().parent
OUTPUT = PAPER / "exponent-allocation-source.zip"


def runtime_sources() -> dict[str, bytes]:
    """Bundle existing frozen-evaluation entrypoints and their local imports."""
    repo = PAPER / 'runtime' if (PAPER / 'runtime/experiments').is_dir() else PAPER.parent
    bundled = repo == PAPER / 'runtime'
    snapshot = json.loads((PAPER / 'figs/runtime_source_snapshot.json').read_text())

    def content_at_snapshot(path: Path) -> bytes:
        if bundled:
            return path.read_bytes()
        relative = path.relative_to(repo).as_posix()
        addition = snapshot.get('additions', {}).get(relative)
        if addition:
            return (PAPER / addition).read_bytes()
        return subprocess.check_output([
            'git', '-C', str(repo), 'show',
            snapshot['revision'] + ':' + relative,
        ])
    roots = [
        "experiments/iclr2027_strong_evidence_20260915/matched_three_method_quick_report.py",
        "experiments/iclr2027_strong_evidence_20260915/official_yarn_naturalqa.py",
        "experiments/iclr2027_strong_evidence_20260915/four_model_yarn_full13.py",
        "experiments/native_enhancement_oral_20260915/lm_context.py",
        "experiments/native_enhancement_oral_20260915/prepare_native_lm.py",
        "experiments/native_enhancement_oral_20260915/run_native_lm.py",
        "experiments/native_enhancement_oral_20260915/report_native_lm.py",
        "experiments/native_enhancement_oral_20260915/report_confirmation.py",
        "experiments/iclr2027_strong_evidence_20260915/run_natural_long.py",
        "experiments/iclr2027_strong_evidence_20260915/prepare_natural_long.py",
        "experiments/native_contrastive_proximal_20260915/tables.py",
        "experiments/native_contrastive_proximal_20260915/report_ruler.py",
        "experiments/iclr2027_three_track_sprint_20260915/verify_discrete_kernel_equivalence.py",
        "experiments/iclr2027_three_track_sprint_20260915/verify_theory_deepening.py",
        "experiments/fixed_rope_three_interfaces_20260913/matched_naturalqa_report.py",
        "experiments/fixed_rope_three_interfaces_20260913/prepare_tailspline_llama_32k_ruler200_clean.py",
        "experiments/fixed_rope_three_interfaces_20260913/prepare_tailspline_llama_naturalqa631.py",
        "experiments/fixed_rope_three_interfaces_20260913/matched_generation_report.py",
        "experiments/llama3_60dir_20260911/prepare_planb_panel.py",
        "experiments/nongeometric_screen/prepare_long_sources.py",
        "experiments/fixed_rope_three_interfaces_20260913/prepare_llama_ppl46.py",
        "experiments/fixed_rope_three_interfaces_20260913/prepare_olmo_ppl46.py",
        "experiments/fixed_rope_three_interfaces_20260913/tables.py",
        "experiments/olmo_recovery_20260912/recovery_v2_eval.py",
        "experiments/fixed_rope_three_interfaces_20260913/tailspline_llama_classic_report.py",
        "experiments/fixed_rope_three_interfaces_20260913/tailspline_olmo_classic_report.py",
        "experiments/kanana_yarn_tailspline_64k_20260918/prepare.py",
        "experiments/kanana_yarn_tailspline_64k_20260918/prepare_mrpro.py",
        "experiments/kanana_yarn_tailspline_64k_20260918/prepare_qa128k_tables.py",
        "experiments/kanana_yarn_tailspline_64k_20260918/report_three_arm_full.py",
        "experiments/kanana_yarn_tailspline_64k_20260918/report_qa_two_arm.py",
    ]
    pending = [repo / name for name in roots]
    files: set[Path] = set()

    def enqueue(parts: list[str]) -> None:
        base = repo.joinpath(*parts)
        for candidate in [base.with_suffix('.py'), base / '__init__.py']:
            if candidate.is_file() and candidate not in files:
                pending.append(candidate)

    while pending:
        path = pending.pop()
        if path in files:
            continue
        files.add(path)
        parent = list(path.relative_to(repo).parts[:-1])
        for count in range(1, len(parent) + 1):
            init = repo.joinpath(*parent[:count], '__init__.py')
            if init.is_file() and init not in files:
                pending.append(init)
        for node in ast.walk(ast.parse(content_at_snapshot(path).decode())):
            if isinstance(node, ast.Import):
                for item in node.names:
                    enqueue(item.name.split('.'))
            elif isinstance(node, ast.ImportFrom):
                prefix = parent[:len(parent) - node.level + 1] if node.level else []
                parts = prefix + (node.module.split('.') if node.module else [])
                enqueue(parts)
                for item in node.names:
                    if item.name != '*':
                        enqueue(parts + [item.name])
    return {'runtime/' + p.relative_to(repo).as_posix(): content_at_snapshot(p) for p in sorted(files)}


def source_files() -> set[Path]:
    files: set[Path] = set()

    def add(path: Path) -> None:
        path = path.resolve()
        if not path.is_relative_to(PAPER) or not path.is_file():
            raise ValueError(f"Missing or external manuscript dependency: {path.name}")
        if path in files:
            return
        files.add(path)
        if path.suffix != ".tex":
            return
        content = re.sub(r"(?<!\\)%[^\n]*", "", path.read_text())
        for name in re.findall(r"\\(?:input|include)\{([^}]+)\}", content):
            add(PAPER / (name if Path(name).suffix else name + ".tex"))
        for name in re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", content):
            add(PAPER / "figs" / (name if Path(name).suffix else name + ".pdf"))
        for name in re.findall(r"\\bibliography\{([^}]+)\}", content):
            for part in name.split(","):
                add(PAPER / (part + ".bib"))

    add(PAPER / "main.tex")
    for name in ["main.pdf", "main.bbl", "compile.sh", "package_source.py", "SUPPLEMENT_README.md", "title_abstract.txt",
                 "runtime/README.md", "figs/fig_intro_claim.svg",
                 "figs/make_intro_claim.py", "figs/intro_claim_inputs.json",
                 "figs/revision_evidence_inputs.json", "figs/make_revision_evidence.py",
                 "figs/revision_evidence_verification.json",
                 "figs/native_control_verification.json", "figs/runtime_source_snapshot.json",
                 "figs/verify_distance_response.py", "figs/selected_theory_verification.json",
                 "figs/verify_finite_content_response.py", "figs/focused_tail_priority_verification.json",
                 "figs/field_gap_inputs.json", "figs/verify_field_gap.py",
                 "figs/allocation_design.py", "figs/make_allocation_value.py", "figs/allocation_value_inputs.json",
                 "figs/make_fig_exact_range_control.py",
                 "figs/verify_interval_design.py", "figs/interval_development_inputs.json",
                 "figs/make_m4_tradeoff.py", "figs/m4_tradeoff_inputs.json", "figs/m4_tradeoff_points.csv",
                 "figs/verify_explicit_geometry.py", "figs/explicit_geometry_examples.json",
                 "figs/verify_allocation_response.py", "figs/allocation_response_inputs.json",
                 "figs/allocation_response_verification.json",
                 "figs/completed_evidence_inputs.json", "figs/verify_completed_evidence.py",
                 "figs/completed_evidence_verification.json",
                 "figs/make_exponent_revision_figures.py", "figs/figure_inputs.json",
                 "figs/profile_diagnostic_inputs.json", "figs/verify_profile_diagnostics.py",
                 "figs/make_story_figures.py", "figs/story_figure_inputs.json",
                 "figs/finite_window_geometry.json", "figs/verify_recovered_assets.py",
                 "figs/recovered_asset_inputs.json", "figs/verify_routing_schedule.py",
                 "figs/routing_protocol_receipts.json", "figs/exponent_revision_source_receipt.json", "figs/llama_temporal_summary.json", "figs/recorded_runtime_identities.json"]:
        add(PAPER / name)
    for path in (PAPER / "extended-records").rglob("*"):
        if path.is_file():
            files.add(path.resolve())
    for pattern in ["*.sty", "*.bst"]:
        for path in PAPER.glob(pattern):
            add(path)
    return files


def main() -> None:
    files = sorted(source_files())
    manifest = []
    with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            relative = path.relative_to(PAPER).as_posix()
            content = path.read_bytes()
            if path.suffix in {".tex", ".bib"} and re.search(rb"/Users/|/root/|sshpass", content):
                raise ValueError(f"Private path in manuscript source: {relative}")
            archive.writestr(relative, content)
            manifest.append(f"{hashlib.sha256(content).hexdigest()}  {relative}")
        runtime = runtime_sources()
        for relative, content in runtime.items():
            archive.writestr(relative, content)
            manifest.append(f"{hashlib.sha256(content).hexdigest()}  {relative}")
        archive.writestr("SHA256SUMS", "\n".join(manifest) + "\n")
        archive.writestr("README.txt", (
            "Beyond the Base: Frequency Allocation in RoPE\n\n"
            "This archive contains the complete active TeX source, bibliography,\n"
            "local style files, plotted figures, and compiled manuscript PDF.\n"
            "Unzip into an empty directory and run: bash compile.sh\n"
            "Requirements: pdflatex with bibtex, or Tectonic.\n\n"
            "The recorded-result figures and tables can be regenerated:\n"
            "  python3 figs/make_exponent_revision_figures.py\n"
            "  python3 figs/make_story_figures.py\n"
            "  python3 figs/make_m4_tradeoff.py\n"
            "  python3 figs/make_allocation_value.py\n"
            "  python3 figs/make_revision_evidence.py\n"
            "  python3 figs/make_intro_claim.py\n"
            "  python3 figs/make_fig_exact_range_control.py\n"
            "  python3 figs/allocation_design.py\n"
            "This uses the bundled figs/figure_inputs.json, with original-source\n"
            "SHA256 values and the 778 natural-QA row scores (no prompt/output text).\n"
            "Python requirements: NumPy and Matplotlib. Regeneration performs no\n"
            "model execution. The remaining historical figures are supplied as PDF.\n\n"
            "Verify the two explicit finite-frequency examples:\n"
            "  python3 figs/verify_field_gap.py\n"
            "  python3 figs/verify_explicit_geometry.py\n"
            "  python3 figs/verify_allocation_response.py\n"
            "  python3 figs/verify_completed_evidence.py\n"
            "  python3 figs/verify_interval_design.py\n"
            "  python3 figs/verify_profile_diagnostics.py\n"
            "  python3 figs/verify_recovered_assets.py\n"
            "  python3 figs/verify_routing_schedule.py\n\n"
            "The appendix contains the mathematical derivations and experimental\n"
            "protocols. Frozen experiment entrypoints and local imports are in\n"
            "runtime/. See runtime/README.md for execution instructions. Model\n"
            "checkpoints and raw experiment streams are maintained separately.\n"
        ))
    print(f"Packaged {len(files)} manuscript files and {len(runtime)} runtime files: {OUTPUT.name} ({OUTPUT.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
