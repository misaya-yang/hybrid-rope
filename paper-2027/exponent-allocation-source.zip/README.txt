Beyond the Base: Exponent Allocation in RoPE

This archive contains the complete active TeX source, bibliography,
local style files, plotted figures, and compiled manuscript PDF.
Unzip into an empty directory and run: bash compile.sh
Requirements: pdflatex with bibtex, or Tectonic.

The recorded-result figures and tables can be regenerated:
  python3 figs/make_exponent_revision_figures.py
  python3 figs/make_story_figures.py
  python3 figs/make_m4_tradeoff.py
  python3 figs/make_allocation_value.py
  python3 figs/allocation_design.py
This uses the bundled figs/figure_inputs.json, with original-source
SHA256 values and the 778 natural-QA row scores (no prompt/output text).
Python requirements: NumPy and Matplotlib. Regeneration performs no
model execution. The remaining historical figures are supplied as PDF.

Verify the two explicit finite-frequency examples:
  python3 figs/verify_explicit_geometry.py
  python3 figs/verify_interval_design.py
  python3 figs/verify_profile_diagnostics.py
  python3 figs/verify_recovered_assets.py
  python3 figs/verify_routing_schedule.py

The appendix contains the mathematical derivations and experimental
protocols. This is a manuscript source archive; model checkpoints
and raw experiment streams are maintained separately.
