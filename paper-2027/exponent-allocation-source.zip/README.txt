Beyond the Base: Exponent Allocation in RoPE

This archive contains the complete active TeX source, bibliography,
local style files, plotted figures, and compiled manuscript PDF.
Unzip into an empty directory and run: bash compile.sh
Requirements: a TeX installation with pdflatex and bibtex.

Five revised figures and four result tables can be regenerated:
  python3 figs/make_exponent_revision_figures.py
This uses the bundled figs/figure_inputs.json, with original-source
SHA256 values and the 778 natural-QA row scores (no prompt/output text).
Python requirements: NumPy and Matplotlib. Regeneration performs no
model execution. The remaining historical figures are supplied as PDF.

Verify the two explicit finite-frequency examples:
  python3 figs/verify_explicit_geometry.py

The appendix contains the mathematical derivations and experimental
protocols. This is a manuscript source archive; model checkpoints
and raw experiment streams are maintained separately.
