#!/usr/bin/env python3
"""Evaluate v2 adapters on complete generation and held-out long LM, without SHA gates."""
from __future__ import annotations
import argparse
from collections import defaultdict
import json
from pathlib import Path

ARMS=('Native','Cosh_tau_sqrt2','Cosh_tau1','Cosh_tau2','C42V24_g4','CoshDeploy_tau1_g4','BM_g4',
      'BM_g8','MrPro_g4','MrPro_g8','MrUni_g4','BetaSym_gamma1p5_g4','BetaSym_gamma3_g4',
      'BetaSym_gamma3_g8','RangeBridge50_g8','BM_g8_RangeGain')
CHECKPOINT_ARMS=ARMS+('Cosh_tau_sqrt2_gradual_install',)
LENGTHS=(4096,8192,16384,32768)


def resolve_lm_lengths(requested, manifest):
    """Keep legacy defaults while allowing explicit longer prepared LM grids."""
    values = tuple(int(value) for value in requested) if requested else LENGTHS
    if len(set(values)) != len(values) or any(value <= 0 for value in values):
        raise ValueError('LM lengths must be unique positive integers')
    prepared = manifest.get('lengths') or []
    if requested and prepared and not set(values).issubset({int(value) for value in prepared}):
        raise ValueError('requested LM length is absent from the prepared manifest')
    return values


def read_rows(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write(path,value):
    path=Path(path);temporary=path.with_name(path.name+'.incomplete')
    temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)


def normalize_existing_identity(value):
    normalized=dict(value)
    if 'generation_order' not in normalized and int(normalized.get('batch_size',1))==1:
        normalized['generation_order']='panel_order_v1'
    return normalized


def checkpoint_precision_identity(model_path):
    """Describe checkpoint storage/compute precision before the expensive load."""
    config_path = Path(model_path) / 'config.json'
    config = json.loads(config_path.read_text())
    quantization = config.get('quantization_config') or {}
    if quantization.get('load_in_4bit'):
        quant_type = str(quantization.get('bnb_4bit_quant_type') or 'unknown')
        compute = str(quantization.get('bnb_4bit_compute_dtype') or 'unknown')
        return {
            'model_dtype': f'bitsandbytes_4bit_{quant_type}_compute_{compute}',
            'checkpoint_quantization': {
                'load_in_4bit': True,
                'bnb_4bit_quant_type': quant_type,
                'bnb_4bit_compute_dtype': compute,
                'bnb_4bit_use_double_quant': bool(
                    quantization.get('bnb_4bit_use_double_quant', False)
                ),
            },
        }
    return {'model_dtype': 'bfloat16', 'checkpoint_quantization': None}


def collect_rows(args,manifest):
    panels=[]
    if not args.only_extra_panels:
        panels.extend((Path(p),'v2_synthetic') for p in manifest.get('evaluation_panels',{}).get(args.split,[]))
        if args.regression_data:
            panels.extend((args.regression_data/f'{kind}_{args.split}.jsonl','regression_'+kind) for kind in ('qa','native'))
    panels.extend((p,'extra_'+p.parent.name) for p in args.extra_panel)
    selected=[];seen=set();cells=defaultdict(int)
    for path,suite in panels:
        if not path.is_file():raise FileNotFoundError(path)
        for index,row in enumerate(read_rows(path)):
            if args.row_split and row.get('split')!=args.row_split:continue
            if row.get('task')=='text':continue
            prompt=row.get('prompt_ids')
            if not prompt and 'target_start' in row:prompt=row['input_ids'][:row['target_start']]
            refs=row.get('references') or ([row['answer']] if row.get('answer') else [])
            if not prompt or not refs:continue
            task=row.get('task',row.get('family','qa'))
            budget=int(row.get('max_new_tokens',row.get('generation_budget',256)))
            cap=int(row.get('length_cap',row.get('length_bucket',next((x for x in LENGTHS if len(prompt)+budget<=x),32768))))
            if budget<=0 or len(prompt)+budget>cap:raise ValueError('prompt/generation reserve exceeds recorded physical length')
            cell=(suite,task,cap)
            if args.limit_per_cell and cells[cell]>=args.limit_per_cell:continue
            identifier=str(row.get('row_id',row.get('id',index)));eval_id=f'{suite}:{identifier}'
            if eval_id in seen:raise ValueError('duplicate evaluation row ID')
            seen.add(eval_id);cells[cell]+=1
            selected.append({**row,'eval_id':eval_id,'suite':suite,'task':task,'prompt_ids':prompt,
                             'references':refs,'max_new_tokens':budget,'length_cap':cap})
    return selected


def normalized(text):
    return text.strip().lower().strip(' .,!;:\"\'`\n\t')


def greedy_tokens(
    model, ids, *, max_new_tokens, eos_ids, pad_token_id,
    prefill_chunk_size=0, unmasked_unpadded=False,
):
    if not prefill_chunk_size or ids.shape[1] <= prefill_chunk_size:
        attention_mask = None if unmasked_unpadded else ids.new_ones(ids.shape)
        return model.generate(ids, attention_mask=attention_mask, do_sample=False, num_beams=1,
                              repetition_penalty=1., no_repeat_ngram_size=0, max_new_tokens=max_new_tokens,
                              eos_token_id=list(eos_ids), pad_token_id=pad_token_id,
                              use_cache=True)[0, ids.shape[1]:].tolist()
    from .runtime import register_blackwell_chunked_attention
    previous_attention = model.config._attn_implementation
    register_blackwell_chunked_attention(model)
    try:
        return chunked_greedy_tokens(model, ids, max_new_tokens=max_new_tokens,
                                     eos_ids=eos_ids, prefill_chunk_size=prefill_chunk_size)
    finally:
        model.config._attn_implementation = previous_attention


def batched_greedy_tokens(
    model, prompt_ids, *, max_new_tokens, eos_ids, pad_token_id, left_pad=False,
):
    """Generate a batch, optionally left-padding only at the attention-mask layer."""
    import torch

    lengths = [len(values) for values in prompt_ids]
    if not left_pad and len(set(lengths)) != 1:
        raise ValueError("Flash-only batching requires equal prompt lengths")
    maximum = max(lengths)
    if left_pad:
        if pad_token_id is None:
            raise ValueError("left-padded batching requires a tokenizer pad token")
        ids = torch.full(
            (len(prompt_ids), maximum), int(pad_token_id), device="cuda", dtype=torch.long,
        )
        mask = torch.zeros_like(ids)
        for index, values in enumerate(prompt_ids):
            length = len(values)
            ids[index, maximum - length:] = torch.tensor(values, device="cuda", dtype=torch.long)
            mask[index, maximum - length:] = 1
    else:
        ids = torch.tensor(prompt_ids, device="cuda", dtype=torch.long)
        mask = torch.ones_like(ids)
    output = model.generate(
        ids, attention_mask=mask, do_sample=False, num_beams=1,
        repetition_penalty=1., no_repeat_ngram_size=0,
        max_new_tokens=max_new_tokens, eos_token_id=list(eos_ids),
        pad_token_id=pad_token_id, use_cache=True,
    )[:, maximum:]
    results = []
    for sequence in output.tolist():
        trimmed = []
        for token in sequence:
            trimmed.append(token)
            if token in eos_ids:
                break
        results.append(trimmed)
    return results


def chunked_greedy_tokens(model, ids, *, max_new_tokens, eos_ids, prefill_chunk_size):
    import torch
    from transformers import DynamicCache
    cache = DynamicCache()
    total = 0
    logits = None
    for start in range(0, ids.shape[1], prefill_chunk_size):
        piece = ids[:, start:start + prefill_chunk_size]
        stop = start + piece.shape[1]
        output = model(input_ids=piece, attention_mask=ids.new_ones((1, stop)),
                       past_key_values=cache, use_cache=True,
                       cache_position=torch.arange(start, stop, device=ids.device),
                       logits_to_keep=1, return_dict=True)
        cache = output.past_key_values
        logits = output.logits[:, -1, :]
        total = stop
        del output
    generated = []
    for step in range(max_new_tokens):
        token = logits.argmax(dim=-1)
        value = int(token.item()); generated.append(value)
        if value in eos_ids or step + 1 == max_new_tokens:
            break
        output = model(input_ids=token[:, None], attention_mask=ids.new_ones((1, total + 1)),
                       past_key_values=cache, use_cache=True,
                       cache_position=torch.tensor([total], device=ids.device),
                       logits_to_keep=1, return_dict=True)
        cache = output.past_key_values
        logits = output.logits[:, -1, :]
        total += 1
        del output
    return generated


def lm_loss_rows(model, token_ids, *, tail=128, chunk_size=128, prefill_chunk_size=0):
    """Compute exact next-token NLL without importing unrelated evaluation data code."""
    import torch.nn.functional as F
    if token_ids.ndim != 2 or token_ids.shape[0] != 1 or token_ids.shape[1] < 2:
        raise ValueError('LM window must have shape [1,L+1]')
    prediction_tokens = token_ids.shape[1] - 1
    if prefill_chunk_size and prediction_tokens > prefill_chunk_size:
        return chunked_lm_loss_rows(
            model, token_ids, tail=tail, logit_chunk_size=chunk_size,
            prefill_chunk_size=prefill_chunk_size,
        )
    hidden=model.model(input_ids=token_ids[:,:-1],use_cache=False).last_hidden_state[0]
    targets=token_ids[0,1:];count=int(targets.numel());tail_count=min(int(tail),count)
    whole_sum=tail_sum=0.
    for start in range(0,count,chunk_size):
        stop=min(start+chunk_size,count)
        logits=F.linear(hidden[start:stop],model.lm_head.weight).float()
        losses=F.cross_entropy(logits,targets[start:stop],reduction='none')
        whole_sum+=float(losses.sum().detach());overlap=max(start,count-tail_count)
        if overlap<stop:tail_sum+=float(losses[overlap-start:].sum().detach())
    return {'whole_loss_sum':whole_sum,'whole_target_count':count,
            'tail128_loss_sum':tail_sum,'tail128_target_count':tail_count,
            'lm_prefill_chunk_size':0}


def chunked_lm_loss_rows(
    model, token_ids, *, tail=128, logit_chunk_size=128, prefill_chunk_size,
):
    """Score every next token while retaining exact left context in a KV cache."""
    import torch
    import torch.nn.functional as F
    from transformers import DynamicCache
    from .runtime import register_blackwell_chunked_attention

    count = token_ids.shape[1] - 1
    if prefill_chunk_size <= 0 or logit_chunk_size <= 0:
        raise ValueError('chunk sizes must be positive')
    cache = DynamicCache()
    whole_sum = 0.0
    tail_sum = 0.0
    tail_count = min(int(tail), count)
    tail_start = count - tail_count
    previous_attention = model.config._attn_implementation
    register_blackwell_chunked_attention(model)
    try:
        for start in range(0, count, prefill_chunk_size):
            stop = min(start + prefill_chunk_size, count)
            piece = token_ids[:, start:stop]
            output = model.model(
                input_ids=piece,
                attention_mask=token_ids.new_ones((1, stop)),
                past_key_values=cache,
                use_cache=True,
                cache_position=torch.arange(start, stop, device=token_ids.device),
                return_dict=True,
            )
            cache = output.past_key_values
            hidden = output.last_hidden_state[0]
            targets = token_ids[0, start + 1:stop + 1]
            for local_start in range(0, stop - start, logit_chunk_size):
                local_stop = min(local_start + logit_chunk_size, stop - start)
                logits = F.linear(
                    hidden[local_start:local_stop], model.lm_head.weight
                ).float()
                losses = F.cross_entropy(
                    logits, targets[local_start:local_stop], reduction='none'
                )
                whole_sum += float(losses.sum())
                global_start = start + local_start
                global_stop = start + local_stop
                overlap = max(global_start, tail_start)
                if overlap < global_stop:
                    tail_sum += float(losses[overlap - global_start:].sum())
            del output, hidden
    finally:
        model.config._attn_implementation = previous_attention
    return {
        'whole_loss_sum': whole_sum,
        'whole_target_count': count,
        'tail128_loss_sum': tail_sum,
        'tail128_target_count': tail_count,
        'lm_prefill_chunk_size': int(prefill_chunk_size),
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True,help='v2 data manifest')
    parser.add_argument('--model',type=Path,required=True);parser.add_argument('--arm',choices=ARMS,required=True)
    parser.add_argument('--checkpoint',type=Path);parser.add_argument('--checkpoint-arm',choices=CHECKPOINT_ARMS)
    parser.add_argument('--split',choices=['dev','test'],default='dev')
    parser.add_argument('--row-split',choices=['fit','select','internal_confirm'],
                        help='for explicit panels, retain only rows carrying this prepared split')
    parser.add_argument('--regression-data',type=Path);parser.add_argument('--extra-panel',type=Path,action='append',default=[])
    parser.add_argument('--only-extra-panels',action='store_true',help='evaluate only explicitly supplied panels')
    parser.add_argument('--skip-lm',action='store_true',help='skip the held-out LM panel for generation-only downstream runs')
    parser.add_argument('--lm-limit-documents',type=int,default=0,help='0 keeps every held-out LM document')
    parser.add_argument('--lm-length-cap',type=int,action='append',default=[],
                        help='restrict LM evaluation to these prepared lengths; default is the legacy full grid')
    parser.add_argument('--length-cap',type=int,action='append',default=[],help='keep only these physical length caps')
    parser.add_argument('--task',action='append',default=[],help='keep only these generation tasks')
    parser.add_argument('--limit-per-cell',type=int,default=0,help='0 keeps every row; a positive limit is explicitly reported as a subset')
    parser.add_argument('--prefill-chunk-size',type=int,default=0,
                        help='0 uses stock generate; positive values enable exact-context chunked KV prefill')
    parser.add_argument('--lm-prefill-chunk-size',type=int,default=0,
                        help='0 uses direct no-cache LM scoring; positive values use exact-context cached chunks')
    parser.add_argument('--batch-size',type=int,default=1,
                        help='contiguous exact-length generation batch using Flash SDPA')
    parser.add_argument('--left-pad-batches',action='store_true',
                        help='batch variable prompt lengths using masked left pad tokens; prompt content and position ids are unchanged')
    parser.add_argument('--unmasked-unpadded-generate',action='store_true',
                        help='omit the redundant all-ones mask for exact batch-1 unpadded generation')
    parser.add_argument('--phi3-sliding-flex',action='store_true',
                        help='preserve Phi-3 local causal attention with sparse FlexAttention')
    parser.add_argument('--longest-first',action='store_true',
                        help='when batching, sort physical length caps descending before shape grouping')
    parser.add_argument('--static-table-json',type=Path,
                        help='install the table object (or result.table) from this frozen solver receipt')
    parser.add_argument('--table-label',help='result label for --static-table-json; does not alter the table')
    parser.add_argument('--ca-ncp-alignment-npz',type=Path,
                        help='install frozen post-norm/pre-RoPE CA-NCP rank-2 Q/K planes')
    parser.add_argument('--ca-ncp-alignment-label',
                        help='result label for --ca-ncp-alignment-npz; does not alter the planes')
    parser.add_argument('--native-followup-method',
                        choices=('mass_projection','mass_raw','even_only','odd_only','rank_assignment'),
                        help='install one frozen Native/NCP dual-frequency attention operator')
    parser.add_argument('--native-followup-candidate-table',type=Path,
                        help='frozen NCP table used by --native-followup-method')
    parser.add_argument('--layer-override-table-json',type=Path,
                        help='mechanism-only table installed in a fixed layer block')
    parser.add_argument('--layer-override-range',
                        help='zero-based START:STOP exclusive block for --layer-override-table-json')
    parser.add_argument('--layer-override-label',
                        help='result arm label for the mechanism-only layer override')
    parser.add_argument('--out',type=Path,required=True);parser.add_argument('--execute',action='store_true')
    args=parser.parse_args();manifest=json.loads(args.data.read_text())
    if not args.execute:
        print(json.dumps({'status':'PLAN_ONLY','arm':args.arm,'checkpoint':str(args.checkpoint) if args.checkpoint else None,
                          'split':args.split,'row_split':args.row_split,'lengths':LENGTHS,
                          'static_table_json':str(args.static_table_json) if args.static_table_json else None,
                          'ca_ncp_alignment_npz':str(args.ca_ncp_alignment_npz) if args.ca_ncp_alignment_npz else None,
                          'ca_ncp_alignment_label':args.ca_ncp_alignment_label,
                          'native_followup_method':args.native_followup_method,
                          'native_followup_candidate_table':str(args.native_followup_candidate_table) if args.native_followup_candidate_table else None,
                          'layer_override_table_json':str(args.layer_override_table_json) if args.layer_override_table_json else None,
                          'layer_override_range':args.layer_override_range,
                          'layer_override_label':args.layer_override_label,
                          'asset_identity_policy':'user_attested_clone/no_sha_validation'}));return
    lm_lengths=resolve_lm_lengths(args.lm_length_cap,manifest)
    if (args.limit_per_cell<0 or args.lm_limit_documents<0 or args.prefill_chunk_size<0
            or args.lm_prefill_chunk_size<0 or args.batch_size<1
            or len(set(lm_lengths))!=len(lm_lengths)):
        raise ValueError('limits and prefill chunk size must be nonnegative')
    import numpy as np
    import torch
    import transformers
    from transformers import AutoTokenizer
    from .recovery_v2_runtime import load_model
    from .runtime import validate_cuda
    from scripts.eval.longbench_metrics import qa_f1_score
    validate_cuda();rows=collect_rows(args,manifest)
    if args.length_cap:
        allowed=set(args.length_cap);rows=[row for row in rows if row['length_cap'] in allowed]
    if args.task:
        allowed_tasks=set(args.task);rows=[row for row in rows if row['task'] in allowed_tasks]
    if args.batch_size > 1:
        rows=sorted(rows,key=lambda row:(
            -row['length_cap'] if args.longest_first else row['length_cap'],
            row['max_new_tokens'],len(row['prompt_ids']),row['task'],row['eval_id']))
    lm_path=None if args.skip_lm else manifest.get('lm_evaluation',{}).get(args.split)
    if not rows and not lm_path:raise ValueError('no evaluation material supplied')
    state=json.loads((args.checkpoint/'state.json').read_text()) if args.checkpoint else {}
    checkpoint_arm=args.checkpoint_arm or args.arm
    if args.checkpoint is None and args.checkpoint_arm:raise ValueError('--checkpoint-arm requires --checkpoint')
    if args.static_table_json and args.checkpoint:
        raise ValueError('--static-table-json is a frozen-model evaluation and cannot use a checkpoint')
    if args.table_label and not args.static_table_json:
        raise ValueError('--table-label requires --static-table-json')
    if bool(args.ca_ncp_alignment_npz) != bool(args.ca_ncp_alignment_label):
        raise ValueError('CA-NCP alignment file and label must be provided together')
    if bool(args.native_followup_method) != bool(args.native_followup_candidate_table):
        raise ValueError('Native follow-up method and candidate table must be provided together')
    if args.native_followup_method and (args.static_table_json or args.ca_ncp_alignment_npz or args.layer_override_table_json):
        raise ValueError('Native follow-up operator cannot be combined with another runtime intervention')
    if args.unmasked_unpadded_generate and (args.batch_size != 1 or args.left_pad_batches):
        raise ValueError('unmasked unpadded generation requires batch=1 without left padding')
    if args.phi3_sliding_flex and not args.unmasked_unpadded_generate:
        raise ValueError('Phi sliding FlexAttention requires the unpadded batch-one path')
    if bool(args.layer_override_table_json) != bool(args.layer_override_range):
        raise ValueError('layer override table and range must be provided together')
    if bool(args.layer_override_table_json) != bool(args.layer_override_label):
        raise ValueError('layer override table and label must be provided together')
    static_table=None
    if args.static_table_json:
        payload=json.loads(args.static_table_json.read_text())
        static_table=payload.get('table',payload)
        values=np.asarray(static_table.get('values_float32'),dtype=np.float32)
        gain=float(static_table.get('gain'))
        if values.ndim!=1 or len(values)<2 or not np.isfinite(values).all() or not np.all(values[:-1]>values[1:]) or not np.isfinite(gain) or gain<=0:
            raise ValueError('invalid frozen solver table')
        static_table={'values_float32':values.tolist(),'gain':gain,
                      'construction':static_table.get('construction',{})}
    layer_override_table=None
    layer_override_layers=()
    if args.layer_override_table_json:
        payload=json.loads(args.layer_override_table_json.read_text())
        layer_override_table=payload.get('table',payload)
        values=np.asarray(layer_override_table.get('values_float32'),dtype=np.float32)
        gain=float(layer_override_table.get('gain'))
        if values.ndim!=1 or len(values)<2 or not np.isfinite(values).all() or not np.all(values[:-1]>values[1:]) or not np.isfinite(gain) or gain<=0:
            raise ValueError('invalid layer override table')
        from experiments.native_enhancement_oral_20260915.layer_phase_override import parse_layer_range
        config=json.loads((args.model/'config.json').read_text())
        layer_override_layers=parse_layer_range(
            args.layer_override_range,num_hidden_layers=int(config['num_hidden_layers']))
        layer_override_table={'values_float32':values.tolist(),'gain':gain,
                              'construction':layer_override_table.get('construction',{})}
    result_arm=args.ca_ncp_alignment_label or args.layer_override_label or args.table_label or args.arm
    ca_ncp_alignment_identity=None
    if args.ca_ncp_alignment_npz:
        from experiments.ca_ncp_native_20260917.io_utils import file_sha256
        from experiments.ca_ncp_native_20260917.runtime import load_alignment
        load_alignment(args.ca_ncp_alignment_npz)
        ca_ncp_alignment_identity={
            'label':args.ca_ncp_alignment_label,
            'path':str(args.ca_ncp_alignment_npz.resolve()),
            'sha256':file_sha256(args.ca_ncp_alignment_npz),
            'hook_location':'model-specific Q/K projection-or-norm output before RoPE; exact site recorded at runtime',
        }
    if state and state.get('arm')!=checkpoint_arm:raise ValueError('checkpoint belongs to another arm')
    precision_identity=checkpoint_precision_identity(args.model)
    identity={'arm':result_arm,'base_arm':args.arm,'checkpoint_arm':checkpoint_arm if args.checkpoint else None,
              'split':args.split,'seed':state.get('seed'),'input_tokens':state.get('input_tokens'),
              'unadapted':args.checkpoint is None,'row_ids':[r['eval_id'] for r in rows],
              'lengths':list(LENGTHS),'generation_length_caps':sorted({r['length_cap'] for r in rows}),
              'lm_enabled':bool(lm_path),'lm_limit_documents':args.lm_limit_documents,
              'lm_lengths':list(lm_lengths),
              'limit_per_cell':args.limit_per_cell,
              'prefill_chunk_size':args.prefill_chunk_size,
              'generation_prefill_strategy':('direct_generate_v1' if args.prefill_chunk_size==0 else 'dynamic_cache_lower_right_v1'),
              'lm_prefill_chunk_size':args.lm_prefill_chunk_size,
              'lm_execution_strategy':('direct_no_cache_v1' if args.lm_prefill_chunk_size==0 else 'dynamic_cache_exact_nll_v1'),
              'batch_size':args.batch_size,
              'unmasked_unpadded_generate':bool(args.unmasked_unpadded_generate),
              'phi3_sliding_flex':bool(args.phi3_sliding_flex),
              'generation_order':(
                  'longest_first_shape_sorted_v1' if args.batch_size>1 and args.longest_first
                  else 'ascending_shape_sorted_v1' if args.batch_size>1
                  else 'panel_order_v1'),
              'runtime_versions':{
                  'torch':torch.__version__,'transformers':transformers.__version__,
                  **precision_identity,'loss_logits_dtype':'float32',
                  'attention_backend':(
                      'phi3_sliding_flex_v1' if args.phi3_sliding_flex
                      else 'torch_sdpa_flash_only'),
                  'cache_type':'DynamicCache' if (args.prefill_chunk_size or args.lm_prefill_chunk_size) else None,
                  'allow_tf32':bool(torch.backends.cuda.matmul.allow_tf32),
              },
              **({'left_pad_batches':True} if args.left_pad_batches else {}),
              'row_split':args.row_split,'static_table':static_table,
              **({'ca_ncp_alignment':ca_ncp_alignment_identity} if ca_ncp_alignment_identity else {}),
              **({'native_followup_method':args.native_followup_method,
                  'native_followup_candidate_table':str(args.native_followup_candidate_table.resolve())}
                 if args.native_followup_method else {}),
              'layer_override':({
                  'layers_zero_based':list(layer_override_layers),
                  'table':layer_override_table,
                  'scope':'mechanism-only fixed layer block; not a deployable static table',
              } if layer_override_table else None)}
    args.out.mkdir(parents=True,exist_ok=True);contract=args.out/'contract.json'
    if contract.exists():
        existing=json.loads(contract.read_text());existing_identity=normalize_existing_identity(existing)
        expected_identity=dict(identity)
        if 'layer_override' not in existing_identity and expected_identity.get('layer_override') is None:
            expected_identity.pop('layer_override')
        if existing_identity!=expected_identity:raise ValueError('output contains a different evaluation')
    write(contract,identity)
    model,wrapper,table=load_model(args.model,args.arm,checkpoint=args.checkpoint,training=False)
    if static_table:
        from scripts.experiments.cross_audit.tables import install_static
        install_static(model,np.asarray(static_table['values_float32'],dtype=np.float32),static_table['gain'])
        actual=model.model.rotary_emb.inv_freq.detach().cpu().float().numpy()
        if not np.array_equal(actual,np.asarray(static_table['values_float32'],dtype=np.float32)):
            raise RuntimeError('installed solver table differs from the frozen receipt')
        table=static_table
    if args.phi3_sliding_flex:
        from .runtime import register_phi3_sliding_flex_attention
        register_phi3_sliding_flex_attention(model)
    elif args.unmasked_unpadded_generate:
        # Transformers may still materialize an additive causal mask internally
        # even when callers omit an all-ones padding mask.  Use the existing
        # lower-right Flash-SDPA interface so both prefill and cached decoding
        # remain mask-free, exact, and Flash-only.
        from .runtime import register_blackwell_chunked_attention
        register_blackwell_chunked_attention(model)
    ca_ncp_alignment_handles=[]
    ca_ncp_alignment_receipt=None
    if args.ca_ncp_alignment_npz:
        from experiments.ca_ncp_native_20260917.runtime import install_alignment
        ca_ncp_alignment_handles,ca_ncp_alignment_receipt=install_alignment(
            model,args.ca_ncp_alignment_npz,
        )
        write(args.out/'runtime_ca_ncp_alignment.json',ca_ncp_alignment_receipt)
    native_followup_restore=None
    native_followup_receipt=None
    if args.native_followup_method:
        import numpy as np
        candidate_payload=json.loads(args.native_followup_candidate_table.read_text())
        candidate_table=candidate_payload.get('table',candidate_payload)
        native_table={
            'values_float32':model.model.rotary_emb.inv_freq.detach().cpu().float().numpy().tolist(),
            'gain':float(model.model.rotary_emb.attention_scaling),
        }
        if args.native_followup_method in ('mass_projection','mass_raw'):
            from experiments.native_followup_five_20260917.mass_projection import METHOD_IDS,install
        elif args.native_followup_method in ('even_only','odd_only'):
            from experiments.native_followup_five_20260917.parity_attention import METHOD_IDS,install
        else:
            from experiments.native_followup_five_20260917.rank_assignment import METHOD_IDS,install
        native_followup_restore=install(
            model,native_table,candidate_table,args.native_followup_method,
        )
        from experiments.ca_ncp_native_20260917.io_utils import file_sha256
        native_followup_receipt={
            'status':'NATIVE_FOLLOWUP_INSTALLED_V1',
            'method':args.native_followup_method,
            'method_id':METHOD_IDS[args.native_followup_method],
            'candidate_table_path':str(args.native_followup_candidate_table.resolve()),
            'candidate_table_sha256':file_sha256(args.native_followup_candidate_table),
            'native_source':'model.model.rotary_emb.inv_freq after base model load',
            'gain':1.0,
            'local_radius':getattr(native_followup_restore,'local_radius',None),
            'scope':'frozen inference operator; model weights unchanged',
        }
        write(args.out/'runtime_native_followup.json',native_followup_receipt)
    layer_override_handles=[]
    if layer_override_table:
        if args.batch_size != 1 or args.left_pad_batches:
            raise ValueError('layer override mechanism run requires unpadded batch=1')
        from experiments.native_enhancement_oral_20260915.layer_phase_override import install_layer_phase_override
        layer_override_handles=install_layer_phase_override(
            model,layers=layer_override_layers,
            values_float32=layer_override_table['values_float32'],
            gain=layer_override_table['gain'],
        )
    tokenizer=AutoTokenizer.from_pretrained(args.model,local_files_only=True)
    eos=model.generation_config.eos_token_id;eos=set(eos if isinstance(eos,list) else [eos])
    pad_token_id = tokenizer.pad_token_id
    if pad_token_id is None:
        pad_token_id = model.generation_config.pad_token_id
    if pad_token_id is None:
        pad_token_id = min(eos)
    write(args.out/'runtime_batching.json',{
        'batch_size':args.batch_size,
        'left_pad_batches':bool(args.left_pad_batches),
        'pad_token_id':int(pad_token_id),
        'pad_tokens_attention_masked':bool(args.left_pad_batches),
        'unmasked_unpadded_generate':bool(args.unmasked_unpadded_generate),
        'phi3_sliding_flex':bool(args.phi3_sliding_flex),
    })
    path=args.out/'generations.jsonl';saved=read_rows(path) if path.exists() else []
    if len(saved)>len(rows) or any(row['eval_id']!=rows[i]['eval_id'] for i,row in enumerate(saved)):
        raise ValueError('saved generations are not the expected prefix')
    with path.open('a') as stream,torch.inference_mode():
        cursor=len(saved)
        while cursor < len(rows):
            first=rows[cursor]
            batch=[first]
            while (len(batch)<args.batch_size and cursor+len(batch)<len(rows)
                   and rows[cursor+len(batch)]['max_new_tokens']==first['max_new_tokens']
                   and rows[cursor+len(batch)]['length_cap']==first['length_cap']
                   and (args.left_pad_batches
                        or len(rows[cursor+len(batch)]['prompt_ids'])==len(first['prompt_ids']))):
                batch.append(rows[cursor+len(batch)])
            if len(batch)==1:
                ids=torch.tensor([first['prompt_ids']],device='cuda',dtype=torch.long)
                token_batches=[greedy_tokens(
                    model,ids,max_new_tokens=first['max_new_tokens'],eos_ids=eos,
                    pad_token_id=pad_token_id,prefill_chunk_size=args.prefill_chunk_size,
                    unmasked_unpadded=args.unmasked_unpadded_generate,
                )]
            else:
                token_batches=batched_greedy_tokens(
                    model,[row['prompt_ids'] for row in batch],
                    max_new_tokens=first['max_new_tokens'],eos_ids=eos,
                    pad_token_id=pad_token_id,
                    left_pad=args.left_pad_batches,
                )
            for row,tokens in zip(batch,token_batches):
                ended=bool(tokens and tokens[-1] in eos)
                text=tokenizer.decode(tokens[:-1] if ended else tokens,skip_special_tokens=False,clean_up_tokenization_spaces=False)
                literal=any(text.strip()==ref.strip() for ref in row['references'])
                exact=any(normalized(text)==normalized(ref) for ref in row['references'])
                record={key:row.get(key) for key in (
                    'eval_id','row_id','suite','task','length_cap','input_tokens','prompt_sha256',
                    'document_cluster_id','group_id','source_seed','world','references',
                    'source_document_id','semantic_group_id','generator_seed','depth_profile',
                    'depth_target','depth_error_mean_abs','evidence_positions')}
                record.update(arm=result_arm,generated_ids=tokens,output_text=text,whole_response_f1=qa_f1_score(text,row['references']),
                              literal_exact=literal,literal_exact_plus_eos=literal and ended,normalized_exact=exact,exact_plus_eos=exact and ended,
                              ended_eos=ended,empty=not text.strip(),hit_cap=len(tokens)==row['max_new_tokens'] and not ended)
                if row['task'].startswith('niah_') or row['task'] in ('vt','cwe','fwe','qa_1','qa_2'):
                    from scripts.experiments.olmo_fast_screen.ruler_bench import score
                    record['ruler_official_score']=score(row,text)
                stream.write(json.dumps(record)+'\n');stream.flush();saved.append(record)
            cursor+=len(batch)
            write(args.out/'live.json',{'phase':'generation','completed':len(saved),'total':len(rows)})
    lm_file=args.out/'lm_rows.jsonl';lm_saved=read_rows(lm_file) if lm_file.exists() else []
    if lm_path:
        values=np.load(lm_path,mmap_mode='r',allow_pickle=False)
        if values.ndim!=2 or values.shape[1]<max(lm_lengths)+1:raise ValueError('held-out LM is shorter than the requested grid')
        if args.lm_limit_documents:values=values[:args.lm_limit_documents]
        expected=[(i,length) for i in range(len(values)) for length in lm_lengths]
        if len(lm_saved)>len(expected) or any((row['document'],row['length'])!=expected[i] for i,row in enumerate(lm_saved)):
            raise ValueError('LM output prefix differs')
        with lm_file.open('a') as stream,torch.inference_mode():
            for document,length in expected[len(lm_saved):]:
                tokens=torch.tensor(values[document,:length+1].copy(),device='cuda',dtype=torch.long).unsqueeze(0)
                with torch.autocast('cuda',dtype=torch.bfloat16):record=lm_loss_rows(
                    model,tokens,prefill_chunk_size=args.lm_prefill_chunk_size)
                record.update(document=document,length=length)
                stream.write(json.dumps(record)+'\n');stream.flush();lm_saved.append(record)
    cells=defaultdict(list)
    for row in saved:cells[(row['suite'],row['task'],row['length_cap'])].append(row)
    metrics={}
    for cell,items in cells.items():
        entry={'rows':len(items)}
        for key in ('whole_response_f1','literal_exact','literal_exact_plus_eos','normalized_exact','exact_plus_eos','ended_eos','empty','hit_cap'):
            entry[key]=sum(float(r[key]) for r in items)/len(items)
        official=[r['ruler_official_score'] for r in items if 'ruler_official_score' in r]
        if official:entry['ruler_official_score']=sum(official)/len(official)
        metrics['/'.join(map(str,cell))]=entry
    lm_summary={}
    for length in lm_lengths:
        items=[r for r in lm_saved if r['length']==length]
        if items:lm_summary[str(length)]={'documents':len(items),
            'whole_nll':sum(r['whole_loss_sum'] for r in items)/sum(r['whole_target_count'] for r in items),
            'tail128_nll':sum(r['tail128_loss_sum'] for r in items)/sum(r['tail128_target_count'] for r in items)}
    pairs=defaultdict(list)
    for row in saved:
        if row.get('group_id') and row.get('world') is not None:pairs[(row['suite'],row['group_id'])].append(row)
    paired=[all(r['exact_plus_eos'] for r in items) and normalized(items[0]['output_text'])!=normalized(items[1]['output_text'])
            for items in pairs.values() if len(items)==2 and {r['world'] for r in items}=={0,1}]
    summary={'status':'COMPLETE','identity':identity,'generation_metrics':metrics,'lm_metrics':lm_summary,
             'paired_source_follow':{'groups':len(paired),'accuracy':sum(paired)/len(paired) if paired else None},
             'table':table,'ca_ncp_alignment':ca_ncp_alignment_receipt,
             'native_followup':native_followup_receipt,
             'asset_identity_policy':'user_attested_clone/no_sha_validation',
             'scope':'development/regression or explicit supplied panels; no automatic stability gate or method win'}
    write(args.out/'summary.json',summary);write(args.out/'status.json',{'status':'COMPLETE','rows':len(saved),'lm_rows':len(lm_saved)})


if __name__=='__main__':main()
