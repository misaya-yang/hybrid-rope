# RoPE Has a Spectral Budget — anonymous supplement

This archive contains the ICLR 2027 paper source, the EVQ-Cosh frequency
implementation, the primary fixed-support training entrypoint, frozen figure
generators, CPU diagnostics, tests, and sanitized machine-readable evidence.

## Quick checks

Install the pinned Python dependencies in an isolated Python 3.10 environment:

```bash
python -m pip install -r requirements-lock.txt
```

Build the paper:

```bash
cd paper-2027
./compile.sh
cd ..
```

Regenerate every figure bundled with this paper:

```bash
python paper-2027/figs/make_fig_evidence_overview.py
python paper-2027/figs/make_fig_frequency_geometry.py
python paper-2027/figs/make_fig_exact_range_control.py
python paper-2027/figs/make_fig_range_composition.py
python paper-2027/figs/make_fig_olmo_scale_crossover.py
python paper-2027/figs/make_fig_spectral_budget_scaling.py
```

Run the complete packaged CPU suite and inspect the exact-range entrypoint
without starting training:

```bash
python -m pytest -q
python scripts/core_text_phases/phase16_exact_range_factorial_m4.py --help
```

## Evidence map

| Paper role | Reviewer artifact |
| --- | --- |
| 151.9M three-seed fixed-support result | `data/curated/exact_range_151m_3seed_result.json` |
| 50.9M exact-range factorial | `rebuttal/rebuttal_0723/theory_results/m4_exact_range_factorial_evidence_20260726.json` |
| 99-run zero-search operating-prior study | `data/curated/phase16_99run_manifest.csv`; `scripts/core_text_phases/phase16_formula_optimality_sweep.py` |
| 432M three-seed MLA result | `data/curated/table18_mla_3seed_aggregate.json` |
| Frozen OLMo/Qwen fixed-support controls and Qasper policy endpoint | `data/curated/frozen_fixed_support_mature_20260823.json` |
| 1.485B adapted endpoints and exact Q/K protocol | `rebuttal/rebuttal_0723/theory_results/olmo2_qk_phase_adaptation_20260729/metrics.json` |
| 8B probability and causal remote-source use | `data/curated/llama8b_causal_source_use_s42_20260714.json` |
| 8B adapted RULER endpoint | `rebuttal/rebuttal_0723/theory_results/llama8b_matched_ruler_mix_20260726.json` |
| Full sin/cos geometry and co-adaptation diagnostics | `scripts/analysis/` |

The exact-range data preparation, protocol, model, and training scripts are in
`rebuttal/rebuttal_0723/experiments/fmrope_125m_l256_500m/`. The figure scripts
contain frozen owner values and consistency assertions.
